jquery.fancylike
================

jQuery plugin that allows to customize facebook like button
